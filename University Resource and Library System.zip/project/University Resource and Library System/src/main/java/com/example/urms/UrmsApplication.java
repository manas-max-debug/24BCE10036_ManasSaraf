package com.example.urms;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;

@SpringBootApplication
public class UrmsApplication {
    public static void main(String[] args) {
        SpringApplication.run(UrmsApplication.class, args);
    }

    @Bean
    public CommandLineRunner diagnosticCheck(MongoTemplate template) {
        return args -> {
            System.out.println("\n=== URMS DIAGNOSTIC BOOTSTRAP ===");
            try {
                var list = template.getDb().listCollectionNames();
                System.out.println(" [SUCCESS] Connected to MongoDB Router successfully.");
                System.out.println(" Active collections: " + list);
            } catch (Exception e) {
                System.out.println(" [ERROR] Could not connect to MongoDB Router at port 27017.");
            }
            System.out.println("=====================================\n");
        };
    }
}

@Document(collection = "departments")
class Department {
    @Id private String id;
    private String name;
    private String hodId; 

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getHodId() { return hodId; }
    public void setHodId(String hodId) { this.hodId = hodId; }
}

@Document(collection = "staff")
class Staff {
    @Id private String id;
    private String name;
    private String post;
    private String deptId; 

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getPost() { return post; }
    public void setPost(String post) { this.post = post; }
    public String getDeptId() { return deptId; }
    public void setDeptId(String deptId) { this.deptId = deptId; }
}

@Document(collection = "students")
class Student {
    @Id private String id;
    private String name;
    private String deptId; 
    private List<String> bookIds = new ArrayList<>(); 

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getDeptId() { return deptId; }
    public void setDeptId(String deptId) { this.deptId = deptId; }
    public List<String> getBookIds() { return bookIds; }
    public void setBookIds(List<String> bookIds) { this.bookIds = bookIds; }
}

@Document(collection = "books")
class Book {
    @Id private String id;
    private String title;
    private boolean active = true;

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public boolean isActive() { return active; }
    public void setActive(boolean active) { this.active = active; }
}

@Repository interface DepartmentRepository extends MongoRepository<Department, String> {}
@Repository interface StaffRepository extends MongoRepository<Staff, String> {}
@Repository interface StudentRepository extends MongoRepository<Student, String> {}
@Repository interface BookRepository extends MongoRepository<Book, String> {}

@Service
class UrmsService {
    @Autowired private DepartmentRepository deptRepo;
    @Autowired private StaffRepository staffRepo;
    @Autowired private StudentRepository studentRepo;
    @Autowired private BookRepository bookRepo;

    public Department linkHod(String dId, String sId) {
        Department d = deptRepo.findById(dId).orElseThrow(() -> new RuntimeException());
        staffRepo.findById(sId).orElseThrow(() -> new RuntimeException());
        d.setHodId(sId);
        return deptRepo.save(d);
    }

    public Student linkBook(String sId, String bId) {
        Student s = studentRepo.findById(sId).orElseThrow(() -> new RuntimeException());
        Book b = bookRepo.findById(bId).orElseThrow(() -> new RuntimeException());
        if (!b.isActive()) throw new RuntimeException();
        b.setActive(false);
        bookRepo.save(b);
        s.getBookIds().add(bId);
        return studentRepo.save(s);
    }
}

@RestController
@RequestMapping("/api")
class UrmsController {

    @Autowired private DepartmentRepository deptRepo;
    @Autowired private StaffRepository staffRepo;
    @Autowired private StudentRepository studentRepo;
    @Autowired private BookRepository bookRepo;
    @Autowired private UrmsService service;
    @Autowired private MongoTemplate template;

    @PostMapping("/departments") public Department addDept(@RequestBody Department d) { return deptRepo.save(d); }
    @PostMapping("/staff") public Staff addStaff(@RequestBody Staff s) { return staffRepo.save(s); }
    @PostMapping("/students") public Student addStudent(@RequestBody Student s) { return studentRepo.save(s); }
    @PostMapping("/books") public Book addBook(@RequestBody Book b) { return bookRepo.save(b); }

    @GetMapping("/students") public List<Student> getAll() { return studentRepo.findAll(); }
    @GetMapping("/books") public List<Book> getAllBooks() { return bookRepo.findAll(); }
    @GetMapping("/staff") public List<Staff> getAllStaff() { return staffRepo.findAll(); }
    @GetMapping("/departments") public List<Department> getAllDepts() { return deptRepo.findAll(); }

    @PutMapping("/departments/{dId}/hod/{sId}")
    public ResponseEntity<Department> setHod(@PathVariable String dId, @PathVariable String sId) {
        return ResponseEntity.ok(service.linkHod(dId, sId));
    }

    @PutMapping("/students/{sId}/borrow/{bId}")
    public ResponseEntity<Student> setBook(@PathVariable String sId, @PathVariable String bId) {
        return ResponseEntity.ok(service.linkBook(sId, bId));
    }

    @DeleteMapping("/books/{id}")
    public ResponseEntity<String> delBook(@PathVariable String id) {
        Book b = bookRepo.findById(id).orElseThrow(() -> new RuntimeException());
        if (!b.isActive()) return ResponseEntity.badRequest().body("Cannot delete! The book is borrowed.");
        bookRepo.deleteById(id);
        return ResponseEntity.ok("Book deleted successfully.");
    }

    @DeleteMapping("/admin/collections/drop/{name}")
    public ResponseEntity<String> drop(@PathVariable String name) {
        if (template.collectionExists(name)) {
            template.dropCollection(name);
            return ResponseEntity.ok("Collection dropped successfully.");
        }
        return ResponseEntity.notFound().build();
    }
}