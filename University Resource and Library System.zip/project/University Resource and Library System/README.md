# URMS Backend API Project

## Setup Requirements
- Java 17 or higher
- IDE (Eclipse, IntelliJ, etc.)
- MongoDB running on localhost:27017

## How to Import and Run
1. Extract the ZIP folder.
2. Open your IDE.
3. Choose **Import Project** -> **Existing Maven Project**.
4. Select the extracted folder and click Finish.
5. Wait for the project dependencies to load.
6. Open `src/main/java/com/example/urms/UrmsApplication.java`.
7. Right-click anywhere in the file and select **Run As > Java Application**.
8. The server will start running on port `8080`.
